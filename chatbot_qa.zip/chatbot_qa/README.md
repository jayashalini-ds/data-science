
# Local CLI QA Chatbot

This is a simple local command-line chatbot that answers questions about country capitals using a small built-in knowledge base and a Hugging Face QA model.

---

##  Setup Instructions

1️⃣ Ensure you have Python 3.7+ installed.

2️⃣ Install the required packages:
```bash
pip install transformers torch
```

---

##  How to Run

In your terminal or command prompt, navigate to the folder containing the code files:
```bash
cd path/to/chatbot_qa
```
Then run:
```bash
python interface.py
```

---

##  Sample Interaction Examples

```
Welcome to Local QA Chatbot! Type /exit to quit.

User: What is the capital of France?
Bot: The capital of France is Paris.
User: And what about Italy?
Bot: The capital of Italy is Rome.
User: What is the capital of India?
Bot: The capital of India is New Delhi.
User: /exit
Exiting chatbot. Goodbye!
```

---

##  Notes

✅ This chatbot uses a small built-in knowledge base (France, Italy, Germany, Spain, India, Japan).  
✅ It reformulates incomplete questions like “And what about Italy?” to clear questions internally.  
✅ You can easily expand the knowledge base in `chat_memory.py`.

---

## Credits

Built using:
- [Hugging Face Transformers](https://huggingface.co/transformers/)
- `distilbert-base-cased-distilled-squad` QA model
