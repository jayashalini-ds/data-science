from transformers import pipeline

def load_model():
    # Load a small Question-Answering model from Hugging Face
    qa_pipeline = pipeline("question-answering", model="distilbert-base-cased-distilled-squad")
    return qa_pipeline
