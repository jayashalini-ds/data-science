class KnowledgeBase:
    def __init__(self):
        # Small built-in knowledge base (you can extend this easily!)
        self.context = (
            "France is a country in Europe. The capital of France is Paris. "
            "Italy is a country in Europe. The capital of Italy is Rome. "
            "Germany is a country in Europe. The capital of Germany is Berlin. "
            "Spain is a country in Europe. The capital of Spain is Madrid. "
            "India is a country in Asia. The capital of India is New Delhi. "
            "Japan is a country in Asia. The capital of Japan is Tokyo. "
        )

    def get_context(self):
        return self.context
