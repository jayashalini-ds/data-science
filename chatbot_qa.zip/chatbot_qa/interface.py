from model_loader import load_model
from chat_memory import KnowledgeBase

def extract_country(question):
    countries = ["France", "Italy", "Germany", "Spain", "India", "Japan"]
    for country in countries:
        if country.lower() in question.lower():
            return country
    return None

def main():
    qa_pipeline = load_model()
    kb = KnowledgeBase()
    last_country = None

    print("Welcome to Local QA Chatbot! Type /exit to quit.\n")

    while True:
        user_input = input("User: ")
        if user_input.strip().lower() == "/exit":
            print("Exiting chatbot. Goodbye!")
            break

        # Extract or infer country
        country = extract_country(user_input)
        if not country:
            if last_country:
                # User gave an incomplete question; repeat last country
                country = last_country
            else:
                print("Bot: Sorry, I didn’t catch which country you mean.")
                continue

        # Build a clear question for the model
        clear_question = f"What is the capital of {country}?"

        result = qa_pipeline(question=clear_question, context=kb.get_context())

        # Format the output ourselves
        print(f"Bot: The capital of {country} is {result['answer']}.")

        # Remember last country
        last_country = country

if __name__ == "__main__":
    main()
